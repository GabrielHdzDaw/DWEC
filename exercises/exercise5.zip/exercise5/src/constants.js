export const SERVER_URL = "http://localhost:3000";
export const PROPERTIES_URL = `${SERVER_URL}/properties`;
export const PROVINCES_URL = `${SERVER_URL}/provinces`;